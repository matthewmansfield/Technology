
                           System47 screen saver
                          version 2.2 - freeware
                               July 13, 2005
                      ________________________________
                       http://www.mewho.com/system47/
                            system47@meWho.com

_________________
 - Description
 - Platform
 - Installation Instruction
 - History of Updates
 - Redistribution Notice
 - Disclaimer
 - Feedback
_________________


Description:
============
  This screen saver will display Star Trek LCARS interface on your screen
  with various interesting animations. More animations will be constantly
  added. So visit System47 web site often to download the latest version.




Platform:
=========
  -- Win9x / WinNT / Win2000 / WinXP

     (A Macintosh version of System47 is also available.
      It can be downloaded at System47 web site.)




Installation Instruction: 
=========================
  1. After unzipping the system47.zip file,
     double click on the file - system47 v2.2 setup.exe. 
     This will install the screen saver onto the machine automatically. 
     
  2. Open the "Display" properties from Control Panel. 
     Select the screen saver tab and choose "System47" from 
     the Screen Saver drop down menu. 
     
  3. Click "Ok" to save the setting. And that's it.  




History of Updates:
===================
  Ver. 2.2
     -- Released on July 13, 2005
     -- Long awaited version for Mac OS X.
     -- No new animation sequence added. However "Settings" have 
        been added to this version. Sound volume can be controlled
        now. Also user may specify which animation sequence to
        display.


  Ver. 2.01
     -- Released on Oct. 10, 2000
     -- Bug Fix: A "freeze frame" bug was found in Version 2.0       
     -- First System47 Version 2.x for Macintosh is released.


  Ver. 2.0
     -- Released on Oct. 04, 2000 (finally...)

     -- By popular demand, sound has been added to System47.
        A Silent Mode version is also available for quiet seekers.
        Both versions can be safely installed on the same machine.

     -- More animation sequences are added, including...
          1. Milky Way Galaxy Quadrant Map
          2. Navigational Zooming Window
          3. Warp Speed Display
          4. U.S.S. Enterprise NCC 1701-E Schematics Display

     -- Two new LCARS interfaces have been added.

     -- Scrolling text has been updated for both style and
        animation performance purposes.






  Ver. 1.53
     -- Released on Dec. 24, 1999
     -- First Macintosh version released.
     -- One major animation sequence added.
        This sequence displays 3D disc grids...

  Ver. 1.41
     -- Released on Dec. 3, 1999
     -- Opening start-up sequence animation added.
     -- Scrolling text updated, based on feedback.
 
  Ver. 1.38
     -- Released on Nov. 28, 1999
     -- First version that is released to public.




Redistribution Notice:
======================
  This program is brought to you for free by meWHO.com. 
  Although this screen saver is a freeware, please do not 
  redistribute it on your own web sites. Rather, please 
  link to the System47 Screen Saver web page
  ( http://www.mewho.com/system47/ ), since the program 
  will be updated frequently and the most current version 
  can always be downloaded here. Thank you. 


Disclaimer: (Here comes the boring stuff...)
===========
  THE PROGRAM AND INFORMATION ARE PROVIDED AS IS WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
  PARTICULAR PURPOSE. IN NO EVENT SHALL MEWHO.COM BE LIABLE FOR ANY 
  DAMAGES WHATSOEVER INCLUDING DIRECT, INDIRECT, INCIDENTAL, 
  CONSEQUENTIAL, LOSS OF BUSINESS PROFITS OR SPECIAL DAMAGES, EVEN 
  IF THE AUTHOR HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.




Feedback:
=========
  E-mail to: system47@meWho.com

  Or visit www.meWho.com/system47  
  to leave your comments or suggestions



Copyright (c) 1999-2005  meWho.com

